# krunkit

`krunkit` is a tool to launch configurable virtual machines using the [libkrun](https://github.com/containers/libkrun) platform.

> [!IMPORTANT]
> krunkit is only supported on hosts running macOS 14 or newer.

## Installation

`krunkit` relies on `libkrun`. We provide a Homebrew repository to install `krunkit` and all of its dependencies, installable with:

```
$ brew tap slp/krunkit
$ brew install krunkit
```

## Building from source

As noted above, `krunkit` relies on `libkrun`. Ensure that is installed on your system.

Build and install using default `PREFIX` (`/usr/local`):

```
make
sudo make install
```

To build with `libkrun` from *Homebrew* or *MacPorts* use the appropriate `PREFIX`:

```
make PREFIX=/opt/homebrew
sudo make install PREFIX=/opt/homebrew
```

## Usage

See [`docs/usage.md`](./docs/usage.md).

License: Apache-2.0
